import cv2
import numpy as np
from skimage import morphology, feature, filters, measure, segmentation
from skimage.filters.rank import entropy
from scipy import ndimage as ndi
from pathlib import Path
import matplotlib.pyplot as plt

def imshow(img, title):
    """Utility function to display images during processing"""
    plt.figure(figsize=(10, 10))
    plt.imshow(img, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()

def smooth_mask(mask, gaussian_size=5, gaussian_sigma=2.0, min_size=1000, hole_size=5000):
    """
    Helper function to smooth binary masks
    """
    # Convert to float32 for Gaussian blur
    mask_float = mask.astype(np.float32)
    
    # Apply Gaussian blur
    mask_blurred = cv2.GaussianBlur(mask_float, (gaussian_size, gaussian_size), gaussian_sigma)
    
    # Threshold back to binary
    mask_binary = mask_blurred > 0.5
    
    # Remove small objects and fill holes
    mask_cleaned = morphology.remove_small_objects(mask_binary, min_size=min_size)
    mask_cleaned = morphology.remove_small_holes(mask_cleaned, area_threshold=hole_size)
    
    # Final smoothing
    mask_float = mask_cleaned.astype(np.float32)
    mask_blurred = cv2.GaussianBlur(mask_float, (3, 3), 1.0)
    mask_final = mask_blurred > 0.5
    
    return mask_final

def detect_stroma(img_rgb, img_ycrcb, background):
    """
    Detect stroma using color-based approach with enhanced smoothing
    """
    # Initial color-based detection in YCrCb space
    Cr_bins_n = 50
    divisor = (np.floor(255 / Cr_bins_n).astype(np.uint8))
    Cr_binned = (np.floor(img_ycrcb[:,:,2]/divisor)).astype(np.uint8)
    
    # Find the most common bin
    hist = np.histogram(Cr_binned[~background], bins=Cr_bins_n+1, range=(0, Cr_bins_n+1))[0]
    most_pixels_bin = np.argmax(hist)
    
    # Initial stroma detection based on Cr values
    stroma = Cr_binned == most_pixels_bin
    for i in range(1, 3):  # Include neighboring bins
        stroma |= (Cr_binned == most_pixels_bin - i)
    
    # Remove background
    stroma &= ~background
    
    # Initial smoothing
    stroma = smooth_mask(stroma, gaussian_size=7, gaussian_sigma=2.0, min_size=1500, hole_size=7000)
    
    # Morphological refinement
    vertical_kernel = morphology.rectangle(15, 3)
    stroma = morphology.binary_dilation(stroma, vertical_kernel)
    
    # Second round of smoothing
    stroma = smooth_mask(stroma, gaussian_size=5, gaussian_sigma=1.5, min_size=2000, hole_size=5000)
    
    # Final cleanup
    stroma = morphology.binary_dilation(stroma, morphology.disk(2))
    stroma = morphology.binary_closing(stroma, morphology.disk(3))
    
    return stroma

def detect_epithelia(img_rgb, img_ycrcb, background, stroma):
    """
    Detect epithelial regions with enhanced smoothing
    """
    # Convert to grayscale
    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    
    # Calculate local entropy for cellular pattern detection
    local_entropy = entropy(gray, morphology.disk(3))
    entropy_mask = local_entropy > filters.threshold_otsu(local_entropy)
    
    # Initial epithelia mask
    epithelia = entropy_mask & ~background & ~stroma
    
    # Initial smoothing
    epithelia = smooth_mask(epithelia, gaussian_size=5, gaussian_sigma=1.5, min_size=1000, hole_size=3000)
    
    # Morphological cleanup
    epithelia = morphology.binary_closing(epithelia, morphology.disk(3))
    
    # Second round of smoothing
    epithelia = smooth_mask(epithelia, gaussian_size=3, gaussian_sigma=1.0, min_size=1500, hole_size=4000)
    
    # Final cleanup
    epithelia = morphology.binary_dilation(epithelia, morphology.disk(2))
    epithelia = morphology.binary_closing(epithelia, morphology.disk(2))
    
    return epithelia

def save_results(output_dir, img_rgb, stroma, epithelia, debug_mode=False):
    """Save result images"""
    # Create final visualization with black stroma
    final_img = img_rgb.copy()
    final_img[stroma] = [0, 0, 0]  # Set stroma regions to black
    
    # Save masks
    cv2.imwrite(str(output_dir / "stroma_mask.png"), 
                stroma.astype(np.uint8)*255, 
                [cv2.IMWRITE_PNG_COMPRESSION, 0])
    
    cv2.imwrite(str(output_dir / "epithelia_mask.png"), 
                epithelia.astype(np.uint8)*255, 
                [cv2.IMWRITE_PNG_COMPRESSION, 0])
    
    # Save final visualization
    cv2.imwrite(str(output_dir / "final_result.png"), 
                cv2.cvtColor(final_img, cv2.COLOR_RGB2BGR), 
                [cv2.IMWRITE_PNG_COMPRESSION, 0])
    
    if debug_mode:
        # Create debug visualization
        debug_img = np.zeros((*stroma.shape, 3), dtype=np.uint8)
        debug_img[stroma] = [255, 0, 0]    # Red for stroma
        debug_img[epithelia] = [0, 255, 0]  # Green for epithelia
        
        cv2.imwrite(str(output_dir / "debug_visualization.png"), 
                    debug_img)

def process_image(image_path, output_folder, debug_mode=False):
    """
    Process a single histological image
    """
    # Read and convert image
    img_rgb = cv2.imread(str(image_path))
    if img_rgb is None:
        print(f"Failed to read image: {image_path}")
        return
        
    img_rgb = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2RGB)
    img_ycrcb = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2YCrCb)
    
    # Create output directory
    image_name = Path(image_path).stem
    image_output_dir = Path(output_folder) / image_name
    image_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Detect background
    background = img_rgb.mean(axis=2) > 240
    background = morphology.remove_small_holes(background, 1000)
    
    # Detect tissues
    stroma = detect_stroma(img_rgb, img_ycrcb, background)
    epithelia = detect_epithelia(img_rgb, img_ycrcb, background, stroma)
    
    # Save results
    save_results(image_output_dir, img_rgb, stroma, epithelia, debug_mode)
    
    return stroma, epithelia

def main():
    """Main execution function"""
    # Configuration
    input_folder = "processed_images_sub"
    output_folder = "filtered_images"
    debug_mode = True
    
    # Create output directory
    output_path = Path(output_folder)
    output_path.mkdir(exist_ok=True)
    
    # Process all images
    input_path = Path(input_folder)
    supported_formats = ('.tif', '.png', '.jpg', '.jpeg')
    
    for image_file in input_path.glob('*'):
        if image_file.suffix.lower() in supported_formats:
            print(f"\nProcessing: {image_file}")
            try:
                process_image(image_file, output_path, debug_mode)
                print(f"Successfully processed: {image_file}")
            except Exception as e:
                print(f"Error processing {image_file}: {str(e)}")

if __name__ == "__main__":
    main()