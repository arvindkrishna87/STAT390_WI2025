import cv2
import numpy as np
from pathlib import Path
import time
import random

def get_epithelium_mask(image):
    """
    Get mask of epithelium tissue
    For these specific images:
    - Black (0,0,0) = stroma
    - White (255,255,255) = background
    - Everything else = epithelium
    """
    # Create masks for stroma and background
    stroma_mask = np.all(image == [0, 0, 0], axis=2)
    background_mask = np.all(image == [255, 255, 255], axis=2)
    
    # Epithelium is everything that is not stroma and not background
    epithelium_mask = ~stroma_mask & ~background_mask
    
    return epithelium_mask

def get_visible_region(image, left, top, right, bottom):
    """Get the visible portion of a region that may extend beyond image boundaries"""
    height, width = image.shape[:2]
    
    # Calculate visible region coordinates
    visible_left = max(0, left)
    visible_right = min(width, right)
    visible_top = max(0, top)
    visible_bottom = min(height, bottom)
    
    if visible_right <= visible_left or visible_bottom <= visible_top:
        return None, None, None, None
    
    return visible_left, visible_top, visible_right, visible_bottom

def calculate_coverage(epithelium_mask, existing_rectangles):
    """Calculate percentage of epithelium covered by samples"""
    if not existing_rectangles:
        return 0.0
    
    height, width = epithelium_mask.shape
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    
    for rect in existing_rectangles:
        left, top, right, bottom = rect
        # Get visible portion of the rectangle
        v_left, v_top, v_right, v_bottom = get_visible_region(
            np.zeros((height, width)), left, top, right, bottom
        )
        if v_left is not None:
            coverage_mask[v_top:v_bottom, v_left:v_right] = True
    
    total_epithelium = np.sum(epithelium_mask)
    if total_epithelium == 0:
        return 0.0
        
    covered_epithelium = np.sum(epithelium_mask & coverage_mask)
    return (covered_epithelium / total_epithelium) * 100

def calculate_overlap(rect1, rect2):
    """Calculate overlap percentage between two rectangles"""
    left1, top1, right1, bottom1 = rect1
    left2, top2, right2, bottom2 = rect2
    
    x_left = max(left1, left2)
    y_top = max(top1, top2)
    x_right = min(right1, right2)
    y_bottom = min(bottom1, bottom2)
    
    if x_right <= x_left or y_bottom <= y_top:
        return 0.0
    
    intersection = (x_right - x_left) * (y_bottom - y_top)
    area1 = (right1 - left1) * (bottom1 - top1)
    area2 = (right2 - left2) * (bottom2 - top2)
    
    return intersection / min(area1, area2)

def contains_stroma_and_background(image, left, top, right, bottom):
    """Check if visible portion of region contains both stroma and background"""
    # Get visible portion of the region
    v_left, v_top, v_right, v_bottom = get_visible_region(image, left, top, right, bottom)
    if v_left is None:
        return False
    
    visible_region = image[v_top:v_bottom, v_left:v_right]
    if visible_region.size == 0:
        return False
    
    has_stroma = np.any(np.all(visible_region == [0, 0, 0], axis=2))
    has_background = np.any(np.all(visible_region == [255, 255, 255], axis=2))
    
    return has_stroma and has_background

def update_covered_rows(covered_rows, rect, height):
    """Update set of covered rows based on new rectangle"""
    top = max(0, rect[1])
    bottom = min(height, rect[3])
    for row in range(top, bottom):
        covered_rows.add(row)

def find_sampling_gaps(image, existing_samples, scale_size, epithelium_mask):
    """
    Find gaps between existing samples that are suitable for new sample placement
    Returns list of (x, y, priority) coordinates for potential placement
    """
    height, width = image.shape[:2]
    half_size = scale_size // 2
    
    # Create coverage mask
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    for rect in existing_samples:
        left, top, right, bottom = rect
        v_left, v_top, v_right, v_bottom = get_visible_region(
            np.zeros((height, width)), left, top, right, bottom
        )
        if v_left is not None:
            coverage_mask[v_top:v_bottom, v_left:v_right] = True
    
    # Find uncovered epithelium regions
    uncovered = epithelium_mask & ~coverage_mask
    
    # Use distance transform to find distances to covered regions
    dist_transform = cv2.distanceTransform(
        (~coverage_mask).astype(np.uint8), 
        cv2.DIST_L2, 
        cv2.DIST_MASK_PRECISE
    )
    
    # Mask the distance transform to only include epithelium regions
    dist_transform = dist_transform * uncovered.astype(float)
    
    # Find local maxima in distance transform that are close to scale_size/2
    # This identifies gaps that are approximately the right size
    target_dist = scale_size / 2
    dist_score = np.exp(-np.abs(dist_transform - target_dist) / (scale_size/4))
    
    # Find local maxima
    local_max = np.zeros_like(dist_score, dtype=bool)
    window_size = scale_size // 4
    for i in range(0, height, window_size):
        for j in range(0, width, window_size):
            window = dist_score[i:min(i+window_size, height), 
                              j:min(j+window_size, width)]
            if window.size > 0:
                max_idx = np.unravel_index(np.argmax(window), window.shape)
                local_max[i + max_idx[0], j + max_idx[1]] = True
    
    # Get coordinates of potential placement points
    candidate_points = []
    y_coords, x_coords = np.where(local_max)
    
    for y, x in zip(y_coords, x_coords):
        if not uncovered[y, x]:
            continue
            
        # Calculate dimensions of uncovered region around this point
        region = uncovered[
            max(0, y-half_size):min(height, y+half_size),
            max(0, x-half_size):min(width, x+half_size)
        ]
        
        if region.size == 0:
            continue
            
        # Calculate aspect ratio of uncovered region
        rows, cols = np.where(region)
        if len(rows) == 0 or len(cols) == 0:
            continue
            
        region_height = rows.max() - rows.min() + 1
        region_width = cols.max() - cols.min() + 1
        
        # Priority based on how well dimensions match scale_size
        size_match = min(
            1.0,
            min(region_height, scale_size) / max(region_height, scale_size) *
            min(region_width, scale_size) / max(region_width, scale_size)
        )
        
        # Priority based on distance to target size
        dist_priority = dist_score[y, x]
        
        # Combined priority score
        priority = size_match * dist_priority
        
        candidate_points.append((x, y, priority))
    
    return sorted(candidate_points, key=lambda x: x[2], reverse=True)

def find_closest_valid_point(image, existing_samples, sample_size, width_dict, overlap_threshold):
    """Find valid point prioritizing gaps between samples"""
    height, width = image.shape[:2]
    epithelium_mask = get_epithelium_mask(image)
    half_size = sample_size // 2
    
    # If no existing samples, fall back to random placement
    if not existing_samples:
        return find_random_point(image, existing_samples, sample_size, width_dict)
    
    # Find gaps suitable for sampling
    candidate_points = find_sampling_gaps(image, existing_samples, sample_size, epithelium_mask)
    
    # Try candidate points in order of priority
    for center_x, center_y, _ in candidate_points:
        rect = (
            int(center_x - half_size),
            int(center_y - half_size),
            int(center_x + half_size),
            int(center_y + half_size)
        )
        
        # Validate placement
        if not contains_stroma_and_background(image, *rect):
            continue
            
        # Check overlap with existing samples
        valid_sample = True
        for other_rect in existing_samples:
            if calculate_overlap(rect, other_rect) > overlap_threshold:
                valid_sample = False
                break
                
        if valid_sample:
            return rect
    
    # If no valid gaps found, fall back to edge-adjacent placement
    for existing_rect in existing_samples[-5:]:  # Try recent samples first
        ex_left, ex_top, ex_right, ex_bottom = existing_rect
        gap = 2
        
        # Try positions on sides
        positions = [
            (ex_right + gap, (ex_top + ex_bottom) // 2),
            ((ex_left + ex_right) // 2, ex_bottom + gap),
            (ex_left - sample_size - gap, (ex_top + ex_bottom) // 2),
            ((ex_left + ex_right) // 2, ex_top - sample_size - gap)
        ]
        
        for center_x, center_y in positions:
            if not (0 <= center_y < height and 0 <= center_x < width):
                continue
                
            if not epithelium_mask[int(center_y), int(center_x)]:
                continue
                
            rect = (
                int(center_x - half_size),
                int(center_y - half_size),
                int(center_x + half_size),
                int(center_y + half_size)
            )
            
            if not contains_stroma_and_background(image, *rect):
                continue
                
            valid_sample = True
            for other_rect in existing_samples:
                if calculate_overlap(rect, other_rect) > overlap_threshold:
                    valid_sample = False
                    break
                    
            if valid_sample:
                return rect
    
    # If all else fails, try random placement
    return find_random_point(image, existing_samples, sample_size, width_dict)

def get_epithelium_width_per_row(image):
    """
    Optimized calculation of epithelium width for each row using numpy operations
    """
    epithelium_mask = get_epithelium_mask(image)
    height = epithelium_mask.shape[0]
    width_dict = {}
    
    # Use numpy operations to find runs of True values
    for row in range(height):
        # Get row data
        row_data = epithelium_mask[row]
        if not np.any(row_data):
            continue
            
        # Find transitions
        transitions = np.where(np.diff(np.concatenate(([False], row_data, [False]))))[0]
        
        # Calculate widths of True segments
        widths = transitions[1::2] - transitions[::2]
        
        if len(widths) > 0:
            width_dict[row] = widths.tolist()
    
    return width_dict

def get_valid_rows_for_scale(width_dict, scale_size, covered_rows):
    """
    Optimized version of finding valid rows for a given scale
    Returns numpy array of valid row numbers
    """
    valid_rows = []
    
    # Convert covered_rows to numpy array for faster lookup
    covered_set = set(covered_rows)
    
    # Pre-allocate arrays for better performance
    for row, widths in width_dict.items():
        if row not in covered_set and any(w <= scale_size for w in widths):
            valid_rows.append(row)
            
    return np.array(valid_rows)

def create_sampling_heatmap(image, existing_samples, scale_size, epithelium_mask):
    """Create heatmap with debug logging"""
    height, width = image.shape[:2]
    
    print(f"Creating heatmap for {height}x{width} image")
    print(f"Total epithelium pixels: {np.sum(epithelium_mask)}")
    
    # For first sample, use simpler strategy to ensure placement
    if not existing_samples:
        print("No existing samples - using simplified first placement strategy")
        # Create basic priority map based on epithelium density
        priority_map = np.zeros_like(epithelium_mask, dtype=float)
        window_size = scale_size * 2
        
        for i in range(0, height, scale_size//2):
            for j in range(0, width, scale_size//2):
                window = epithelium_mask[
                    i:min(i + window_size, height),
                    j:min(j + window_size, width)
                ]
                if window.size > 0:
                    density = np.sum(window) / window.size
                    if density > 0:
                        center_y = i + scale_size//2
                        center_x = j + scale_size//2
                        if center_y < height and center_x < width:
                            priority_map[center_y, center_x] = density
        
        return priority_map
    
    # Regular heatmap creation for subsequent samples
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    for rect in existing_samples:
        left, top, right, bottom = rect
        v_left, v_top, v_right, v_bottom = get_visible_region(
            np.zeros((height, width)), left, top, right, bottom
        )
        if v_left is not None:
            coverage_mask[v_top:v_bottom, v_left:v_right] = True
    
    uncovered = epithelium_mask & ~coverage_mask
    dist_to_covered = cv2.distanceTransform(
        (~coverage_mask).astype(np.uint8),
        cv2.DIST_L2,
        cv2.DIST_MASK_PRECISE
    )
    
    max_dist = np.max(dist_to_covered)
    if max_dist > 0:
        dist_to_covered = dist_to_covered / max_dist
    
    gap_score = np.exp(-4 * np.abs(dist_to_covered - 0.5))
    coverage_priority = np.zeros_like(epithelium_mask, dtype=float)
    
    # Calculate coverage priority
    for i in range(0, height, scale_size//2):
        for j in range(0, width, scale_size//2):
            window = uncovered[
                i:min(i + scale_size*2, height),
                j:min(j + scale_size*2, width)
            ]
            if window.size > 0:
                density = np.sum(window) / window.size
                center_y = i + scale_size//2
                center_x = j + scale_size//2
                if center_y < height and center_x < width:
                    coverage_priority[center_y, center_x] = density
    
    coverage_weight = np.exp(-2 * dist_to_covered)
    priority_map = (coverage_weight * gap_score + (1.0 - coverage_weight) * coverage_priority)
    priority_map = priority_map * epithelium_mask
    
    if np.max(priority_map) > 0:
        priority_map = priority_map / np.max(priority_map)
    
    print(f"Priority map created. Max priority: {np.max(priority_map)}")
    return priority_map

def find_next_sample_location(image, existing_samples, scale_size, width_dict, overlap_threshold=None):
    """Find next sample location with specific overlap thresholds"""
    height, width = image.shape[:2]
    epithelium_mask = get_epithelium_mask(image)
    half_size = scale_size // 2
    
    # Set overlap threshold based on scale size
    if overlap_threshold is None:
        if scale_size <= 128:
            overlap_threshold = 0.20
        elif scale_size <= 256:
            overlap_threshold = 0.30
        else:  # 512
            overlap_threshold = 0.40
    
    print(f"\nFinding next sample location (scale: {scale_size})")
    print(f"Using overlap threshold: {overlap_threshold:.2f}")
    print(f"Number of existing samples: {len(existing_samples)}")
    
    # Generate priority map
    priority_map = create_sampling_heatmap(image, existing_samples, scale_size, epithelium_mask)
    
    # For first sample, try simplified placement
    if not existing_samples:
        print("Attempting first sample placement")
        y_coords, x_coords = np.where(epithelium_mask)
        if len(y_coords) > 0:
            for _ in range(100):
                idx = np.random.randint(len(y_coords))
                center_y, center_x = y_coords[idx], x_coords[idx]
                
                rect = (
                    int(center_x - half_size),
                    int(center_y - half_size),
                    int(center_x + half_size),
                    int(center_y + half_size)
                )
                
                if contains_stroma_and_background(image, *rect):
                    print("Found valid first sample location")
                    return rect
        
        print("Failed to find valid first sample location")
        return None
    
    # Find candidate points near existing samples that maximize allowed overlap
    candidates = []
    for existing_rect in existing_samples:
        ex_left, ex_top, ex_right, ex_bottom = existing_rect
        
        # Calculate potential positions that utilize allowed overlap
        overlap_offset = int(scale_size * (1 - overlap_threshold))
        positions = [
            # Right side with overlap
            (ex_right - overlap_offset, (ex_top + ex_bottom) // 2),
            # Left side with overlap
            (ex_left + overlap_offset - scale_size, (ex_top + ex_bottom) // 2),
            # Bottom with overlap
            ((ex_left + ex_right) // 2, ex_bottom - overlap_offset),
            # Top with overlap
            ((ex_left + ex_right) // 2, ex_top + overlap_offset - scale_size),
            # Diagonal positions
            (ex_right - overlap_offset, ex_bottom - overlap_offset),
            (ex_right - overlap_offset, ex_top + overlap_offset - scale_size),
            (ex_left + overlap_offset - scale_size, ex_bottom - overlap_offset),
            (ex_left + overlap_offset - scale_size, ex_top + overlap_offset - scale_size)
        ]
        
        for center_x, center_y in positions:
            if 0 <= center_y < height and 0 <= center_x < width:
                if epithelium_mask[int(center_y), int(center_x)]:
                    priority = priority_map[int(center_y), int(center_x)]
                    if priority > 0:
                        candidates.append((center_x, center_y, priority))
    
    # Add additional candidates from priority map
    y_coords, x_coords = np.where(priority_map > 0)
    for y, x in zip(y_coords, x_coords):
        candidates.append((x, y, priority_map[y, x]))
    
    candidates = list(set(candidates))  # Remove duplicates
    candidates.sort(key=lambda x: x[2], reverse=True)
    print(f"Found {len(candidates)} candidate points")
    
    # Try candidates
    valid_count = 0
    for center_x, center_y, priority in candidates:
        rect = (
            int(center_x - half_size),
            int(center_y - half_size),
            int(center_x + half_size),
            int(center_y + half_size)
        )
        
        # Validate stroma and background
        if not contains_stroma_and_background(image, *rect):
            continue
        
        valid_count += 1
        
        # Check overlap with existing samples
        max_overlap = 0
        valid_sample = True
        for other_rect in existing_samples:
            overlap = calculate_overlap(rect, other_rect)
            max_overlap = max(max_overlap, overlap)
            if overlap > overlap_threshold:
                valid_sample = False
                break
        
        if valid_sample:
            print(f"Found valid location with priority {priority:.3f}")
            print(f"Position: ({center_x}, {center_y})")
            print(f"Maximum overlap: {max_overlap:.3f}")
            return rect
    
    print(f"Checked {valid_count} valid positions containing stroma and background")
    print("No valid location found")
    return None

def create_spatial_grid(image_shape, grid_size):
    """Create a spatial grid for faster neighbor lookups"""
    height, width = image_shape
    grid_rows = (height + grid_size - 1) // grid_size
    grid_cols = (width + grid_size - 1) // grid_size
    return [[[] for _ in range(grid_cols)] for _ in range(grid_rows)]

def add_to_grid(grid, rect, grid_size):
    """Add rectangle to spatial grid"""
    l, t, r, b = rect
    grid_left = max(0, l // grid_size)
    grid_right = min(len(grid[0]) - 1, r // grid_size)
    grid_top = max(0, t // grid_size)
    grid_bottom = min(len(grid) - 1, b // grid_size)
    
    for gr in range(grid_top, grid_bottom + 1):
        for gc in range(grid_left, grid_right + 1):
            grid[gr][gc].append(rect)

def get_nearby_samples(grid, rect, grid_size):
    """Get nearby samples from spatial grid"""
    l, t, r, b = rect
    grid_left = max(0, l // grid_size)
    grid_right = min(len(grid[0]) - 1, r // grid_size)
    grid_top = max(0, t // grid_size)
    grid_bottom = min(len(grid) - 1, b // grid_size)
    
    nearby = []
    seen = set()  # Avoid duplicates
    for gr in range(grid_top, grid_bottom + 1):
        for gc in range(grid_left, grid_right + 1):
            for sample in grid[gr][gc]:
                sample_tuple = tuple(sample)
                if sample_tuple not in seen:
                    nearby.append(sample)
                    seen.add(sample_tuple)
    return nearby

def save_visualization(image, output_dir, samples, scale, coverage):
    """Save visualization of samples at current scale"""
    viz_image = image.copy()
    height, width = viz_image.shape[:2]
    
    # Draw all samples
    for rect in samples:
        left, top, right, bottom = rect
        # Get visible portion of rectangle
        v_left, v_top, v_right, v_bottom = get_visible_region(viz_image, left, top, right, bottom)
        if v_left is not None:
            cv2.rectangle(viz_image, (v_left, v_top), (v_right, v_bottom), (0, 255, 0), 2)
    
    # Add coverage text
    cv2.putText(
        viz_image,
        f"Scale: {scale}x{scale}, Coverage: {coverage:.2f}%",
        (10, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 0, 255),
        2
    )
    
    output_path = output_dir / f"coverage_{scale}x{scale}.png"
    cv2.imwrite(str(output_path), viz_image)

def save_individual_samples(image, output_dir, samples, scale):
    """Save individual samples to separate files"""
    samples_dir = output_dir / f"samples_{scale}x{scale}"
    samples_dir.mkdir(exist_ok=True)
    
    # Create a metadata file for this scale
    with open(samples_dir / "metadata.txt", "w") as f:
        f.write(f"Scale: {scale}x{scale}\n")
        f.write(f"Total samples: {len(samples)}\n")
        f.write("\nSample coordinates (left, top, right, bottom):\n")
        
        for i, rect in enumerate(samples):
            # Save individual sample image
            left, top, right, bottom = rect
            v_left, v_top, v_right, v_bottom = get_visible_region(image, left, top, right, bottom)
            
            if v_left is not None:
                sample_img = image[v_top:v_bottom, v_left:v_right].copy()
                # Add border to visualize the sample
                sample_img = cv2.copyMakeBorder(
                    sample_img, 2, 2, 2, 2, cv2.BORDER_CONSTANT, value=(0, 255, 0)
                )
                cv2.imwrite(str(samples_dir / f"sample_{i+1:04d}.png"), sample_img)
                
                # Write coordinates to metadata
                f.write(f"Sample {i+1:04d}: {rect}\n")
                f.write(f"Visible region: ({v_left}, {v_top}, {v_right}, {v_bottom})\n")

def save_coverage_statistics(output_dir, scale_results, total_coverage, image_name):
    """Enhanced coverage statistics with total coverage information"""
    with open(output_dir / "coverage_statistics.txt", "w") as f:
        f.write(f"Coverage Analysis for {image_name}\n")
        f.write("=" * 50 + "\n\n")
        
        f.write("Overall Coverage Statistics:\n")
        f.write(f"Total Coverage: {total_coverage:.2f}%\n")
        f.write("-" * 50 + "\n\n")
        
        for scale, (samples, coverage) in scale_results.items():
            f.write(f"Scale: {scale}x{scale}\n")
            f.write(f"Samples placed: {len(samples)}\n")
            f.write(f"Final coverage: {coverage[-1] if coverage else 0.0:.2f}%\n")
            f.write("\nCoverage progression:\n")
            for i, cov in enumerate(coverage, 1):
                if i % 10 == 0 or i == len(coverage):  # Log every 10th sample and final
                    f.write(f"  Sample {i}: {cov:.2f}%\n")
            f.write("-" * 50 + "\n\n")

def process_tissue_at_scale(image, scale_size, existing_samples, width_dict):
    """Process tissue exhaustively at each scale until no valid areas remain"""
    height, width = image.shape[:2]
    epithelium_mask = get_epithelium_mask(image)
    samples_at_scale = []
    coverage_history = []
    
    # Set overlap threshold based on scale
    if scale_size <= 128:
        overlap_threshold = 0.20
    elif scale_size <= 256:
        overlap_threshold = 0.30
    else:  # 512
        overlap_threshold = 0.40
    
    print(f"\nProcessing scale: {scale_size}x{scale_size}")
    print(f"Overlap threshold: {overlap_threshold*100}%")
    
    # Create spatial grid for fast neighbor lookups
    grid_size = scale_size
    spatial_grid = create_spatial_grid((height, width), grid_size)
    
    # Add existing samples to grid
    for rect in existing_samples:
        add_to_grid(spatial_grid, rect, grid_size)
    
    # Pre-calculate valid points on epithelium
    valid_points = np.where(epithelium_mask)
    valid_points = list(zip(valid_points[1], valid_points[0]))  # x, y coordinates
    random.shuffle(valid_points)  # Randomize points
    
    if not valid_points:
        return [], []
    
    # Initialize efficient tracking of coverage
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    for rect in existing_samples:
        l, t, r, b = rect
        vl, vt, vr, vb = get_visible_region(coverage_mask, l, t, r, b)
        if vl is not None:
            coverage_mask[vt:vb, vl:vr] = True
    
    half_size = scale_size // 2
    consecutive_failures = 0
    total_attempts = 0
    
    print("Starting exhaustive sampling...")
    
    while valid_points and consecutive_failures < 1000:
        total_attempts += 1
        
        if total_attempts % 1000 == 0:
            print(f"Attempts: {total_attempts}, Valid points remaining: {len(valid_points)}")
            print(f"Current samples: {len(samples_at_scale)}")
        
        # Get next point
        center_x, center_y = valid_points.pop()
        
        rect = (
            center_x - half_size,
            center_y - half_size,
            center_x + half_size,
            center_y + half_size
        )
        
        # Quick boundary check
        if not (0 <= center_y < height and 0 <= center_x < width):
            consecutive_failures += 1
            continue
        
        # Check if contains stroma and background
        if not contains_stroma_and_background(image, *rect):
            consecutive_failures += 1
            continue
        
        # Check overlap only with nearby samples
        valid_sample = True
        nearby_samples = get_nearby_samples(spatial_grid, rect, grid_size)
        
        for other_rect in nearby_samples:
            if calculate_overlap(rect, other_rect) > overlap_threshold:
                valid_sample = False
                break
        
        if not valid_sample:
            consecutive_failures += 1
            continue
        
        # Valid sample found
        consecutive_failures = 0
        samples_at_scale.append(rect)
        add_to_grid(spatial_grid, rect, grid_size)
        
        # Update coverage mask
        l, t, r, b = rect
        vl, vt, vr, vb = get_visible_region(coverage_mask, l, t, r, b)
        if vl is not None:
            coverage_mask[vt:vb, vl:vr] = True
        
        # Check coverage periodically
        if len(samples_at_scale) % 10 == 0:
            current_coverage = np.sum(coverage_mask & epithelium_mask) / np.sum(epithelium_mask) * 100
            coverage_history.append(current_coverage)
            print(f"Current coverage: {current_coverage:.2f}%")
            print(f"Samples placed: {len(samples_at_scale)}")
    
    # Calculate final coverage
    final_coverage = np.sum(coverage_mask & epithelium_mask) / np.sum(epithelium_mask) * 100
    coverage_history.append(final_coverage)
    
    print(f"\nScale {scale_size}x{scale_size} completed:")
    print(f"Total samples placed: {len(samples_at_scale)}")
    print(f"Final coverage at this scale: {final_coverage:.2f}%")
    print(f"Total attempts made: {total_attempts}")
    
    return samples_at_scale, coverage_history

def process_tissue(image_path, debug_output_dir):
    """Process tissue image with exhaustive multi-scale sampling"""
    image = cv2.imread(str(image_path))
    if image is None:
        print(f"Failed to read image: {image_path}")
        return None, None, None
    
    # Calculate epithelium widths for all rows
    width_dict = get_epithelium_width_per_row(image)
    
    # Define scales in order from smallest to largest
    scales = [128, 256, 512]
    
    all_samples = []
    scale_results = {}
    epithelium_mask = get_epithelium_mask(image)
    
    # Create output directory
    debug_output_dir = Path(debug_output_dir)
    debug_output_dir.mkdir(parents=True, exist_ok=True)
    
    for scale in scales:
        print(f"\nStarting scale {scale}x{scale}")
        print("=" * 50)
        
        # Process at current scale
        samples_at_scale, coverage_history = process_tissue_at_scale(
            image,
            scale,
            all_samples,
            width_dict
        )
        
        all_samples.extend(samples_at_scale)
        scale_results[scale] = (samples_at_scale, coverage_history)
        
        # Save individual samples
        save_individual_samples(image, debug_output_dir, samples_at_scale, scale)
        
        # Save visualization for this scale
        save_visualization(
            image,
            debug_output_dir,
            all_samples,
            scale,
            coverage_history[-1] if coverage_history else 0.0
        )
        
        # Calculate and display intermediate total coverage
        current_total_coverage = calculate_coverage(epithelium_mask, all_samples)
        print(f"Total coverage after {scale}x{scale}: {current_total_coverage:.2f}%")
    
    # Calculate final total coverage
    total_coverage = calculate_coverage(epithelium_mask, all_samples)
    
    # Save final statistics
    save_coverage_statistics(
        debug_output_dir, 
        scale_results, 
        total_coverage,
        image_path.name
    )
    
    return all_samples, scale_results, total_coverage

def main():
    input_folder = Path("prashant2")
    output_folder = Path("new_output")
    output_folder.mkdir(exist_ok=True)
    
    # Track overall statistics across all images
    overall_stats = []
    
    for image_path in input_folder.iterdir():
        if image_path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.tif']:
            print(f"\nProcessing: {image_path}")
            
            image_output_dir = output_folder / image_path.stem
            image_output_dir.mkdir(parents=True, exist_ok=True)
            
            try:
                samples, scale_results, total_coverage = process_tissue(image_path, image_output_dir)
                if samples is None:
                    continue
                    
                # Save to overall statistics
                overall_stats.append({
                    'image': image_path.name,
                    'total_coverage': total_coverage,
                    'samples_by_scale': {
                        scale: len(samples_at_scale) 
                        for scale, (samples_at_scale, _) in scale_results.items()
                    }
                })
                
                # Print summary
                print("\nProcessing Summary:")
                print(f"Total Coverage: {total_coverage:.2f}%")
                for scale, (samples_at_scale, coverage_history) in scale_results.items():
                    print(f"\nScale {scale}x{scale}:")
                    print(f"Samples placed: {len(samples_at_scale)}")
                    print(f"Final coverage: {coverage_history[-1] if coverage_history else 0.0:.2f}%")
                       
            except Exception as e:
                print(f"Error processing {image_path}: {str(e)}")
                import traceback
                traceback.print_exc()
    
    # Save overall statistics
    with open(output_folder / "overall_statistics.txt", "w") as f:
        f.write("Overall Processing Statistics\n")
        f.write("=" * 50 + "\n\n")
        
        for stats in overall_stats:
            f.write(f"Image: {stats['image']}\n")
            f.write(f"Total Coverage: {stats['total_coverage']:.2f}%\n")
            f.write("Samples by scale:\n")
            for scale, count in stats['samples_by_scale'].items():
                f.write(f"  {scale}x{scale}: {count} samples\n")
            f.write("-" * 50 + "\n\n")

if __name__ == "__main__":
    main()