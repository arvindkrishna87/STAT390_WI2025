import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from pathlib import Path
import re

class TissueImageProcessor:
    def __init__(self, input_dir, output_base_dir):
        self.input_dir = Path(input_dir)
        self.output_base_dir = Path(output_base_dir)
        self.box_sizes = [650, 520, 260, 130]
        self.epithelium_thresholds = {
            650: 70,
            520: 30,
            260: 20,
            130: 20
        }
        self.step_sizes = {size: size for size in self.box_sizes}
        self.box_colors = {
            650: (255, 165, 0),  # Orange
            520: (255, 0, 0),    # Blue
            260: (0, 255, 0),    # Green
            130: (0, 0, 255)     # Red
        }

    def create_directory_structure(self):
        """Create the necessary directory structure for output"""
        # Create main output directories
        self.output_base_dir.mkdir(parents=True, exist_ok=True)
        
        # Create directories for different outputs
        self.patient_dir = self.output_base_dir / "patients"
        self.annotated_dir = self.output_base_dir / "annotated_images"
        
        for dir_path in [self.patient_dir, self.annotated_dir]:
            dir_path.mkdir(exist_ok=True)

    def extract_image_info(self, image_path):
        """Extract patient ID and ROI number from image path"""
        filename = image_path.stem
        patient_id = filename[:8]
        
        # Extract ROI number using regex
        roi_match = re.search(r'ROI_(\d+)', filename)
        roi_number = roi_match.group(1) if roi_match else "unknown"
        
        return patient_id, roi_number

    def create_patient_directories(self, patient_id, roi_number):
        """Create patient-specific directories including ROI subdirectories"""
        # Create patient directory
        patient_dir = self.patient_dir / patient_id
        patient_dir.mkdir(exist_ok=True)
        
        # Create patient's original images directory
        originals_dir = patient_dir / "original_images"
        originals_dir.mkdir(exist_ok=True)
        
        # Create patient's samples directory
        samples_dir = patient_dir / "samples"
        samples_dir.mkdir(exist_ok=True)
        
        # Create ROI-specific directory under samples
        roi_dir = samples_dir / f"ROI_{roi_number}"
        roi_dir.mkdir(exist_ok=True)
        
        return patient_dir, originals_dir, roi_dir

    def compute_overlap(self, boxA, boxB):
        """Compute overlap percentage between two boxes"""
        x_left = max(boxA['left'], boxB['left'])
        y_top = max(boxA['top'], boxB['top'])
        x_right = min(boxA['right'], boxB['right'])
        y_bottom = min(boxA['bottom'], boxB['bottom'])

        if x_right <= x_left or y_bottom <= y_top:
            return 0.0

        intersection_area = (x_right - x_left) * (y_bottom - y_top)
        areaA = (boxA['right'] - boxA['left']) * (boxA['bottom'] - boxA['top'])
        areaB = (boxB['right'] - boxB['left']) * (boxB['bottom'] - boxB['top'])

        overlap_percentage_A = (intersection_area / areaA) * 100
        overlap_percentage_B = (intersection_area / areaB) * 100

        return max(overlap_percentage_A, overlap_percentage_B)

    def process_image(self, image_path):
        """Process a single image and return the results"""
        image = cv2.imread(str(image_path))
        if image is None:
            print(f"Failed to load image: {image_path}")
            return None

        # Create masks and initialize variables
        epithelium_mask = cv2.inRange(image, np.array([1, 1, 1]), np.array([255, 255, 255]))
        boxes = {size: [] for size in self.box_sizes}
        zoomed_in_regions = []
        rect_dimensions = []
        image_with_rectangles = image.copy()

        # Get epithelium bounds
        coords = cv2.findNonZero(epithelium_mask)
        x, y, w, h = cv2.boundingRect(coords)
        start_x = x
        start_y = y
        end_x = x + w
        end_y = y + h

        # Initialize covered mask
        covered_mask = np.zeros_like(epithelium_mask)

        # Process each box size
        for size in self.box_sizes:
            box_list = boxes[size]
            step_size = self.step_sizes[size]
            color = self.box_colors[size]
            required_coverage = self.epithelium_thresholds[size]
            half_size = size // 2
            max_shift = half_size
            shift_step = 10
            print(f"Processing boxes of size {size}x{size}")

            # Update remaining epithelium mask
            remaining_epithelium_mask = cv2.bitwise_and(epithelium_mask, cv2.bitwise_not(covered_mask))

            for top in range(start_y, end_y, step_size):
                for left in range(start_x, end_x, step_size):
                    best_coverage = 0
                    best_shifted_left = None
                    best_shifted_top = None

                    # Search for optimal position
                    shift_range = range(-max_shift, max_shift + 1, shift_step)
                    for shift_x in shift_range:
                        for shift_y in shift_range:
                            shifted_left = left + shift_x
                            shifted_top = top + shift_y
                            shifted_right = shifted_left + size
                            shifted_bottom = shifted_top + size

                            # Check bounds
                            if (shifted_top < 0 or shifted_left < 0 or 
                                shifted_bottom > image.shape[0] or 
                                shifted_right > image.shape[1]):
                                continue

                            # Extract regions
                            box_region = image[shifted_top:shifted_bottom, 
                                             shifted_left:shifted_right]
                            box_mask = remaining_epithelium_mask[shifted_top:shifted_bottom, 
                                                               shifted_left:shifted_right]

                            # Calculate coverage
                            total_pixels = box_mask.size
                            epithelium_pixels = cv2.countNonZero(box_mask)
                            epithelium_percentage = (epithelium_pixels / total_pixels) * 100

                            if epithelium_percentage >= required_coverage:
                                black_region_mask = cv2.bitwise_not(box_mask)
                                num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(black_region_mask)
                                num_black_regions = num_labels - 1

                                if num_black_regions >= 2:
                                    black_areas = [stats[label, cv2.CC_STAT_AREA] 
                                                 for label in range(1, num_labels)]
                                    total_black_area = sum(black_areas)
                                    largest_black_region_area = max(black_areas)

                                    if largest_black_region_area <= 0.7 * total_black_area:
                                        sorted_indices = np.argsort(-np.array(black_areas))
                                        black_region_labels = [sorted_indices[0] + 1, 
                                                             sorted_indices[1] + 1]
                                        
                                        # Region analysis
                                        height, width = black_region_mask.shape
                                        half_height = height // 2
                                        half_width = width // 2

                                        # Create region masks
                                        regions = {
                                            'top': np.zeros_like(black_region_mask, dtype=np.uint8),
                                            'bottom': np.zeros_like(black_region_mask, dtype=np.uint8),
                                            'left': np.zeros_like(black_region_mask, dtype=np.uint8),
                                            'right': np.zeros_like(black_region_mask, dtype=np.uint8)
                                        }
                                        
                                        regions['top'][0:half_height, :] = 1
                                        regions['bottom'][half_height:, :] = 1
                                        regions['left'][:, 0:half_width] = 1
                                        regions['right'][:, half_width:] = 1

                                        black_region_regions = []
                                        for label in black_region_labels:
                                            region_mask = (labels == label).astype(np.uint8)
                                            overlaps = {
                                                region: cv2.countNonZero(cv2.bitwise_and(region_mask, mask))
                                                for region, mask in regions.items()
                                            }
                                            black_region_regions.append(max(overlaps, key=overlaps.get))

                                        if black_region_regions[0] != black_region_regions[1]:
                                            if epithelium_percentage > best_coverage:
                                                best_coverage = epithelium_percentage
                                                best_shifted_left = shifted_left
                                                best_shifted_top = shifted_top
                                                best_box_region = box_region.copy()

                    # Process best position
                    if best_coverage >= required_coverage and best_shifted_left is not None:
                        current_box = {
                            'left': best_shifted_left,
                            'top': best_shifted_top,
                            'right': best_shifted_left + size,
                            'bottom': best_shifted_top + size
                        }

                        # Check overlap with existing boxes
                        overlap_found = False
                        for other_size in self.box_sizes:
                            if not boxes[other_size]:
                                continue
                            for existing_box in boxes[other_size]:
                                if self.compute_overlap(current_box, existing_box) > 35:
                                    overlap_found = True
                                    break
                            if overlap_found:
                                break

                        if not overlap_found:
                            box_list.append(current_box)
                            zoomed_in_regions.append(best_box_region)
                            rect_dimensions.append((size, size))

                            # Draw rectangle
                            cv2.rectangle(image_with_rectangles, 
                                        (best_shifted_left, best_shifted_top),
                                        (best_shifted_left + size, best_shifted_top + size),
                                        color, 6)

                            # Update covered mask with the new box
                            box_mask = np.zeros_like(covered_mask)
                            box_mask[current_box['top']:current_box['bottom'], 
                                   current_box['left']:current_box['right']] = 1
                            covered_mask = cv2.bitwise_or(covered_mask, box_mask)

            print(f"Found {len(box_list)} boxes of size {size}x{size}")

        return image_with_rectangles, zoomed_in_regions, rect_dimensions

    def save_results(self, image_path, annotated_image, samples, dimensions):
        """Save the processing results with enhanced organization"""
        # Extract patient ID and ROI number
        patient_id, roi_number = self.extract_image_info(image_path)
        
        # Create necessary directories
        patient_dir, originals_dir, roi_dir = self.create_patient_directories(patient_id, roi_number)
        
        # Save annotated image in annotated_images directory
        annotated_filename = f"{image_path.stem}_annotated.png"
        cv2.imwrite(str(self.annotated_dir / annotated_filename), annotated_image)
        
        # Save original image in patient's original_images directory
        original_image = cv2.imread(str(image_path))
        cv2.imwrite(str(originals_dir / image_path.name), original_image)
        
        # Save individual samples in ROI-specific directory
        for i, sample in enumerate(samples, 1):
            # Create sample filename with size information
            width, height = dimensions[i-1]
            sample_filename = f"{image_path.stem}_sample_{i}_{width}x{height}.png"
            cv2.imwrite(str(roi_dir / sample_filename), sample)
        
        # Print processing summary
        print(f"\nProcessed {image_path.name}:")
        print(f"- Patient ID: {patient_id}")
        print(f"- ROI Number: {roi_number}")
        print(f"- Number of samples: {len(samples)}")
        print(f"- Samples saved to: {roi_dir}")
        total_area = sum(w * h for w, h in dimensions)
        print(f"- Total sampled area: {total_area} pixels²")
        print("----------------------------------------")

    def process_directory(self):
        """Process all images in the input directory"""
        # Create output directories
        self.create_directory_structure()
        
        # Get all image files
        image_files = list(self.input_dir.glob("*Epithelia.png"))
        
        if not image_files:
            print("No matching images found in the input directory.")
            return
            
        print(f"Found {len(image_files)} images to process.")
        print("----------------------------------------")
        
        # Group images by patient ID
        patient_images = {}
        for image_path in image_files:
            patient_id = image_path.stem[:8]
            if patient_id not in patient_images:
                patient_images[patient_id] = []
            patient_images[patient_id].append(image_path)
        
        # Process each patient's images
        for patient_id, images in patient_images.items():
            print(f"\nProcessing patient {patient_id}")
            print(f"Found {len(images)} images")
            
            for image_path in images:
                print(f"\nProcessing {image_path.name}")
                try:
                    results = self.process_image(image_path)
                    if results is not None:
                        annotated_image, samples, dimensions = results
                        self.save_results(image_path, annotated_image, samples, dimensions)
                except Exception as e:
                    print(f"Error processing {image_path.name}: {str(e)}")
                    continue

def main():
    # Define input and output directories
    input_directory = "Krish_files"
    output_directory = "patients_172_to_185"
    
    # Create processor instance and process images
    processor = TissueImageProcessor(input_directory, output_directory)
    processor.process_directory()

if __name__ == "__main__":
    main()