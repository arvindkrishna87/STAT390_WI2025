import cv2
import numpy as np
from pathlib import Path
import time
import random

def get_epithelium_mask(image):
    """Get mask of epithelium tissue"""
    stroma_mask = np.all(image == [0, 0, 0], axis=2)
    purple_mask = (image[:,:,0] > 100) & (image[:,:,2] > 100)
    return purple_mask & ~stroma_mask

def calculate_coverage(epithelium_mask, existing_rectangles):
    """Calculate percentage of epithelium covered by samples"""
    if not existing_rectangles:
        return 0.0
        
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    for rect in existing_rectangles:
        left, top, right, bottom = rect
        coverage_mask[top:bottom, left:right] = True
    
    total_epithelium = np.sum(epithelium_mask)
    covered_epithelium = np.sum(epithelium_mask & coverage_mask)
    
    return (covered_epithelium / total_epithelium) * 100

def calculate_overlap(rect1, rect2):
    """Calculate overlap percentage between two rectangles"""
    left1, top1, right1, bottom1 = rect1
    left2, top2, right2, bottom2 = rect2
    
    # Calculate intersection
    x_left = max(left1, left2)
    y_top = max(top1, top2)
    x_right = min(right1, right2)
    y_bottom = min(bottom1, bottom2)
    
    if x_right <= x_left or y_bottom <= y_top:
        return 0.0
    
    intersection = (x_right - x_left) * (y_bottom - y_top)
    area1 = (right1 - left1) * (bottom1 - top1)
    area2 = (right2 - left2) * (bottom2 - top2)
    
    return intersection / min(area1, area2)

def check_corners_non_epithelium(image, left, top, right, bottom):
    """
    Check if all four corners are in non-epithelium (stroma or background)
    """
    corners = {
        'top_left': image[top, left],
        'top_right': image[top, right-1],
        'bottom_left': image[bottom-1, left],
        'bottom_right': image[bottom-1, right-1]
    }
    
    corner_status = {}
    for name, pixel in corners.items():
        is_stroma = np.all(pixel == [0, 0, 0])
        is_background = not is_stroma and not (pixel[0] > 100 and pixel[2] > 100)
        is_non_epithelium = is_stroma or is_background
        corner_status[name] = is_non_epithelium
    
    all_corners_valid = all(corner_status.values())
    
    if not all_corners_valid:
        epithelium_corners = [name for name, status in corner_status.items() if not status]
        print(f"    Corners still in epithelium: {epithelium_corners}")
    
    return all_corners_valid

def check_corners_balanced(image, left, top, right, bottom):
    """
    Check if corners are properly balanced between stroma and background
    Returns (is_valid, reason)
    """
    corners = {
        'top_left': image[top, left],
        'top_right': image[top, right-1],
        'bottom_left': image[bottom-1, left],
        'bottom_right': image[bottom-1, right-1]
    }
    
    # Classify each corner
    corner_types = {}
    stroma_corners = []
    background_corners = []
    epithelium_corners = []
    
    for name, pixel in corners.items():
        if np.all(pixel == [0, 0, 0]):
            corner_types[name] = 'stroma'
            stroma_corners.append(name)
        elif not (pixel[0] > 100 and pixel[2] > 100):  # Not purple (epithelium)
            corner_types[name] = 'background'
            background_corners.append(name)
        else:
            corner_types[name] = 'epithelium'
            epithelium_corners.append(name)
    
    # Check for ideal condition (2 stroma, 2 background)
    if len(stroma_corners) == 2 and len(background_corners) == 2:
        return True, "Ideal balance: 2 stroma, 2 background corners"
    
    # For growth phase, accept any valid non-epithelium configuration
    if not epithelium_corners:
        return True, f"Valid configuration: {len(stroma_corners)} stroma, {len(background_corners)} background corners"
    
    return False, f"Invalid configuration: {len(stroma_corners)} stroma, {len(background_corners)} background, {len(epithelium_corners)} epithelium corners"

def is_stroma(pixel):
    """Check if pixel is stroma (black)"""
    return np.all(pixel == [0, 0, 0])

def is_background(pixel):
    """Check if pixel is background (very light/white)"""
    # More strict background check - looking for very light pixels
    return np.mean(pixel) > 240

def is_epithelium(pixel):
    """Check if pixel is epithelium (purple)"""
    # Not stroma and not background
    return not is_stroma(pixel) and not is_background(pixel)

def check_corners(image, left, top, right, bottom):
    """
    Check corner types (stroma/background/epithelium)
    Returns dict of corner types and bool indicating if all corners are non-epithelium
    """
    corners = {
        'top_left': image[top, left],
        'top_right': image[top, right-1],
        'bottom_left': image[bottom-1, left],
        'bottom_right': image[bottom-1, right-1]
    }
    
    corner_types = {}
    for name, pixel in corners.items():
        if np.all(pixel == [0, 0, 0]):
            corner_types[name] = 'stroma'
        elif np.all(pixel == [255, 255, 255]):
            corner_types[name] = 'background'
        else:
            corner_types[name] = 'epithelium'
    
    all_non_epithelium = all(type != 'epithelium' for type in corner_types.values())
    has_stroma = any(type == 'stroma' for type in corner_types.values())
    has_background = any(type == 'background' for type in corner_types.values())
    
    return corner_types, all_non_epithelium and has_stroma and has_background

def shrink_region(image, left, top, right, bottom):
    """
    Shrink region until any further shrinking would put a corner into epithelium
    """
    shrunk = False
    min_size = 40  # Minimum dimension allowed
    
    print("    Initial corner analysis:")
    is_valid, reason, corner_types = check_corners(image, left, top, right, bottom)
    print(f"    {reason}")
    
    if not is_valid:
        return None
    
    while (right - left) > min_size and (bottom - top) > min_size:
        # Try shrinking each edge
        changes = [
            ('left', left + 1, top, right, bottom),
            ('right', left, top, right - 1, bottom),
            ('top', left, top + 1, right, bottom),
            ('bottom', left, top, right, bottom - 1)
        ]
        
        made_change = False
        for edge, new_left, new_top, new_right, new_bottom in changes:
            # Check if shrinking maintains valid corners
            is_valid, reason, new_corner_types = check_corners(
                image, new_left, new_top, new_right, new_bottom
            )
            
            # Only accept if valid and maintains at least one stroma and one background
            if is_valid:
                left, top, right, bottom = new_left, new_top, new_right, new_bottom
                made_change = True
                shrunk = True
                corner_types = new_corner_types
                print(f"    Shrunk {edge} edge: new size {right-left}x{bottom-top}")
                break
        
        if not made_change:
            print("    Cannot shrink further without entering epithelium")
            break
    
    # Final validation
    is_valid, reason, _ = check_corners(image, left, top, right, bottom)
    if not is_valid:
        print(f"    Rejected: {reason}")
        return None
    
    print(f"    Final configuration: {reason}")
    return (left, top, right, bottom) if shrunk else None

def is_point_in_epithelium(image, x, y):
    """Check if point is in epithelium (purple tissue)"""
    if x < 0 or y < 0 or x >= image.shape[1] or y >= image.shape[0]:
        return False
        
    pixel = image[y, x]
    return not np.all(pixel == [0, 0, 0]) and not np.all(pixel == [255, 255, 255])

def find_random_point(image, existing_samples):
    """Find a random valid point not in existing samples"""
    # Create mask of covered regions
    height, width = image.shape[:2]
    covered = np.zeros((height, width), dtype=bool)
    
    for left, top, right, bottom in existing_samples:
        covered[top:bottom, left:right] = True
    
    # Get valid epithelium coordinates (not black, not white)
    valid_y, valid_x = np.where(
        (~np.all(image == [0, 0, 0], axis=2)) &  # not stroma
        (~np.all(image == [255, 255, 255], axis=2)) &  # not background
        (~covered)  # not in existing samples
    )
    
    if len(valid_y) == 0:
        return None
    
    # Select random point
    idx = random.randint(0, len(valid_y) - 1)
    return (valid_x[idx], valid_y[idx])

def create_sample_around_point(image, center_x, center_y):
    """Create sample with controlled growth and shrinking"""
    # Growth phase - expand until all corners are out of epithelium
    size = 40  # Start with minimum size
    max_size = min(image.shape[0], image.shape[1]) // 2
    
    found_valid = False
    while size <= max_size:
        top = max(0, center_y - size//2)
        bottom = min(image.shape[0], center_y + size//2)
        left = max(0, center_x - size//2)
        right = min(image.shape[1], center_x + size//2)
        
        corner_types, is_valid = check_corners(image, left, top, right, bottom)
        if is_valid:
            found_valid = True
            break
            
        size += 20
    
    if not found_valid:
        return None
    
    # Shrinking phase - maintain corners outside epithelium
    shrink_attempts = 0
    max_shrink_attempts = 50
    
    while shrink_attempts < max_shrink_attempts:
        made_change = False
        shrink_attempts += 1
        
        # Try shrinking each edge
        edges = [
            ('top', 1, 0, 0, 0),    # dy, db, dl, dr
            ('bottom', 0, -1, 0, 0),
            ('left', 0, 0, 1, 0),
            ('right', 0, 0, 0, -1)
        ]
        
        for edge, dt, db, dl, dr in edges:
            new_top = top + dt
            new_bottom = bottom + db
            new_left = left + dl
            new_right = right + dr
            
            # Check if shrinking maintains valid corners
            corner_types, is_valid = check_corners(
                image, new_left, new_top, new_right, new_bottom)
            
            if is_valid:
                top, bottom, left, right = new_top, new_bottom, new_left, new_right
                made_change = True
        
        if not made_change:
            break
    
    return (left, top, right, bottom)

def calculate_sample_statistics(samples):
    """Calculate statistics for sample dimensions"""
    if not samples:
        return None
        
    widths = []
    heights = []
    areas = []
    ratios = []  # height/width ratios
    
    for left, top, right, bottom in samples:
        width = right - left
        height = bottom - top
        widths.append(width)
        heights.append(height)
        areas.append(width * height)
        ratios.append(height / width)
    
    stats = {
        'width': {
            'mean': np.mean(widths),
            'std': np.std(widths),
            'min': np.min(widths),
            'max': np.max(widths)
        },
        'height': {
            'mean': np.mean(heights),
            'std': np.std(heights),
            'min': np.min(heights),
            'max': np.max(heights)
        },
        'area': {
            'mean': np.mean(areas),
            'std': np.std(areas),
            'min': np.min(areas),
            'max': np.max(areas)
        },
        'ratio': {
            'mean': np.mean(ratios),
            'std': np.std(ratios),
            'min': np.min(ratios),
            'max': np.max(ratios)
        }
    }
    
    return stats

def save_statistics(stats, output_path):
    """Save statistics to CSV file"""
    with open(output_path / 'sample_statistics.csv', 'w') as f:
        f.write("Metric,Mean,StdDev,Min,Max\n")
        for metric, values in stats.items():
            f.write(f"{metric},{values['mean']:.2f},{values['std']:.2f}")
            f.write(f",{values['min']:.2f},{values['max']:.2f}\n")

def process_tissue(image_path, debug_output_dir):
    """Process tissue image with sequential sampling"""
    image = cv2.imread(str(image_path))
    if image is None:
        print(f"Failed to read image: {image_path}")
        return []
        
    existing_samples = []
    total_attempts = 0
    max_attempts = 600
    
    while total_attempts < max_attempts:
        total_attempts += 1
        print(f"\nAttempt {total_attempts}/{max_attempts}")
        print(f"Current samples: {len(existing_samples)}")
        
        # Find random point
        point = find_random_point(image, existing_samples)
        if point is None:
            print("No more valid points available")
            break
            
        center_x, center_y = point
        print(f"Selected point: ({center_x}, {center_y})")
        
        # Create sample
        rect = create_sample_around_point(image, center_x, center_y)
        if rect is None:
            print("Failed to create valid sample")
            continue
            
        # Check overlap with existing samples
        valid_sample = True
        for existing_rect in existing_samples:
            overlap = calculate_overlap(rect, existing_rect)
            if overlap > 0.25:  # 25% overlap threshold
                print(f"Rejected: {overlap*100:.1f}% overlap with existing sample")
                valid_sample = False
                break
        
        if valid_sample:
            existing_samples.append(rect)
            print(f"Added sample {len(existing_samples)}")
            
            # Save debug visualization
            if debug_output_dir:
                debug_image = image.copy()
                # Draw all existing samples
                for i, (left, top, right, bottom) in enumerate(existing_samples):
                    color = (0, 0, 255) if i == len(existing_samples)-1 else (255, 0, 0)
                    cv2.rectangle(debug_image, (left, top), (right, bottom), color, 2)
                    if i == len(existing_samples)-1:  # Mark latest point
                        cv2.circle(debug_image, (center_x, center_y), 5, (0, 255, 0), -1)
                
                cv2.imwrite(
                    str(Path(debug_output_dir) / f"sample_{len(existing_samples)}.png"),
                    debug_image
                )
    
    print(f"\nProcessing completed:")
    print(f"Total attempts: {total_attempts}")
    print(f"Samples found: {len(existing_samples)}")
    
    return existing_samples

def save_debug_visualization(image, debug_dir, samples, sample_count):
    """Save visualization of current state"""
    viz_image = image.copy()
    
    # Draw all existing samples
    for i, (left, top, right, bottom) in enumerate(samples):
        color = (0, 0, 255) if i == len(samples)-1 else (255, 0, 0)
        cv2.rectangle(viz_image, (left, top), (right, bottom), color, 2)
    
    output_path = Path(debug_dir) / f"sample_state_{sample_count}.png"
    cv2.imwrite(str(output_path), viz_image)

def main():
    input_folder = Path("prashant")
    output_folder = Path("debug_output")
    output_folder.mkdir(exist_ok=True)
    
    all_tissue_stats = {}
    
    for image_path in input_folder.iterdir():
        if image_path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.tif']:
            print(f"\nProcessing: {image_path}")
            
            image_output_dir = output_folder / image_path.stem
            image_output_dir.mkdir(parents=True, exist_ok=True)
            
            try:
                samples = process_tissue(image_path, image_output_dir)
                
                # Calculate and save statistics
                stats = calculate_sample_statistics(samples)
                if stats:
                    all_tissue_stats[image_path.stem] = stats
                    save_statistics(stats, image_output_dir)
                    
                    print("\nSample Statistics:")
                    print(f"Average width: {stats['width']['mean']:.2f} ± {stats['width']['std']:.2f}")
                    print(f"Average height: {stats['height']['mean']:.2f} ± {stats['height']['std']:.2f}")
                    print(f"Height/Width ratio: {stats['ratio']['mean']:.2f} ± {stats['ratio']['std']:.2f}")
                    
            except Exception as e:
                print(f"Error processing {image_path}: {str(e)}")
                traceback.print_exc()
    
    # Save combined statistics
    if all_tissue_stats:
        with open(output_folder / 'all_tissue_statistics.txt', 'w') as f:
            for tissue, stats in all_tissue_stats.items():
                f.write(f"\n{tissue}:\n")
                f.write(f"Width: {stats['width']['mean']:.2f} ± {stats['width']['std']:.2f}\n")
                f.write(f"Height: {stats['height']['mean']:.2f} ± {stats['height']['std']:.2f}\n")
                f.write(f"H/W Ratio: {stats['ratio']['mean']:.2f} ± {stats['ratio']['std']:.2f}\n")
                f.write("-" * 50 + "\n")

if __name__ == "__main__":
    main()