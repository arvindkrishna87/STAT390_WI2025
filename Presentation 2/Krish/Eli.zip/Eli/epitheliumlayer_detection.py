import cv2
import numpy as np

# Load the image
image_path = "image1.jpg"
image = cv2.imread(image_path)

# Check if the image was loaded correctly
if image is None:
    raise FileNotFoundError(f"Image file not found at path: {image_path}")

# Convert to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Save the grayscale image
cv2.imwrite("final_grayscale_image.jpg", gray_image)

# Apply a Gaussian blur to smooth the image
blurred_image = cv2.GaussianBlur(gray_image, (45, 45), 0)

# Threshold the image to create a binary mask
_, thresholded_mask = cv2.threshold(blurred_image, 200, 255, cv2.THRESH_BINARY_INV)

# Apply large kernel morphological operations to remove small dots and smooth layers
kernel_huge = np.ones((45, 45), np.uint8)
cleaned_mask = cv2.morphologyEx(thresholded_mask, cv2.MORPH_CLOSE, kernel_huge)
cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_OPEN, kernel_huge)

# Find all contours
contours, _ = cv2.findContours(cleaned_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Sort the contours by area and keep only the largest one (the exterior contour)
largest_contour = max(contours, key=cv2.contourArea)

# Draw only the largest contour on the original image with a thick red line
contoured_image = image.copy()
cv2.drawContours(contoured_image, [largest_contour], -1, (0, 0, 255), 8)  # Red line with thickness of 8

# Save the contoured image and the cleaned mask
cv2.imwrite("exterior_contoured_image.jpg", contoured_image)
cv2.imwrite("exterior_cleaned_mask.jpg", cleaned_mask)

# Save the coordinates of the exterior contour
exterior_contour_coords = largest_contour[:, 0, :]
np.savetxt("exterior_contour_coords.txt", exterior_contour_coords, fmt='%d', delimiter=',')

# Print message for successful exterior contour detection
print("Exterior contour marked and saved.")
