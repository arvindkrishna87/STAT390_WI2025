import cv2
import numpy as np
import os

# Directories
input_folder = "processed_images_sub"
output_folder = "filtered_images"
os.makedirs(output_folder, exist_ok=True)

# Paths to output epithelium masks
epithelium_output_folder = os.path.join(output_folder, "epithelium_masks")
os.makedirs(epithelium_output_folder, exist_ok=True)

def extract_regions(image):
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred_image = cv2.GaussianBlur(gray_image, (25, 25), 0)
    _, thresholded_mask = cv2.threshold(blurred_image, 150, 255, cv2.THRESH_BINARY_INV)

    kernel_small = np.ones((20, 20), np.uint8)
    cleaned_mask = cv2.morphologyEx(thresholded_mask, cv2.MORPH_CLOSE, kernel_small)
    cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_OPEN, kernel_small)

    contours, _ = cv2.findContours(cleaned_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    epithelium_mask = np.zeros_like(cleaned_mask)
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)
        cv2.drawContours(epithelium_mask, [largest_contour], -1, (255), thickness=cv2.FILLED)
    return epithelium_mask

def is_overlapping(patch_coords, existing_patches):
    x1, y1, x2, y2 = patch_coords
    for (ex1, ey1, ex2, ey2) in existing_patches:
        # Check for overlap
        if not (x2 <= ex1 or x1 >= ex2 or y2 <= ey1 or y1 >= ey2):
            return True
    return False

def sample_patch_with_debugging(image, epithelium_mask, existing_patches):
    # Create a padded version of the image and mask
    padding = 100  # Adjust padding as needed
    padded_image = cv2.copyMakeBorder(image, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=(0, 0, 0))
    padded_mask = cv2.copyMakeBorder(epithelium_mask, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)

    y_coords, x_coords = np.where(epithelium_mask == 255)
    if len(x_coords) == 0 or len(y_coords) == 0:
        raise ValueError("No epithelium points found for sampling.")
    
    random_index = np.random.randint(0, len(x_coords))
    x_center, y_center = x_coords[random_index] + padding, y_coords[random_index] + padding  # Adjust for padding

    size = 10
    height, width = padded_mask.shape

    def is_in_epithelium(x, y):
        return 0 <= x < width and 0 <= y < height and padded_mask[y, x] == 255

    # Enlargement loop
    while (
        is_in_epithelium(x_center - size, y_center - size) or
        is_in_epithelium(x_center + size, y_center - size) or
        is_in_epithelium(x_center - size, y_center + size) or
        is_in_epithelium(x_center + size, y_center + size)
    ):
        size += 10

    # Calculate the patch coordinates relative to the original image
    left = x_center - size - padding
    right = x_center + size - padding
    top = y_center - size - padding
    bottom = y_center + size - padding

    # Ensure the coordinates are within the original image bounds
    left = max(0, left)
    right = min(image.shape[1], right)
    top = max(0, top)
    bottom = min(image.shape[0], bottom)

    patch_coords = (left, top, right, bottom)
    
    # Check for overlap with existing patches
    if is_overlapping(patch_coords, existing_patches):
        print("Overlap detected; retrying.")
        return None

    # Draw the final patch
    cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 3)
    return patch_coords

def process_and_sample(image_path):
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(f"Image not found at {image_path}")

    epithelium_mask = extract_regions(image)
    filename = os.path.basename(image_path)
    mask_output_path = os.path.join(epithelium_output_folder, f"mask_{filename}")
    cv2.imwrite(mask_output_path, epithelium_mask)

    final_image = image.copy()
    sampled_patches = []
    num_patches = 10  # Number of desired patches

    while len(sampled_patches) < num_patches:
        patch_coords = sample_patch_with_debugging(final_image, epithelium_mask, sampled_patches)
        if patch_coords:
            sampled_patches.append(patch_coords)
            print(f"Patch {len(sampled_patches)}: {patch_coords}")

    final_output_path = os.path.join(output_folder, f"sample_{filename}")
    cv2.imwrite(final_output_path, final_image)

    print(f"Processed {filename}, sample saved at {final_output_path}")

for filename in os.listdir(input_folder):
    if filename.endswith(".tif") or filename.endswith(".jpg") or filename.endswith(".png"):
        image_path = os.path.join(input_folder, filename)
        process_and_sample(image_path)

print("Processing complete for all images.")
