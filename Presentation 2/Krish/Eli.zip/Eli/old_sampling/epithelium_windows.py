import cv2
import numpy as np
import os

# Directories
input_folder = "processed_images"
output_folder = "filtered_images"

# Check if output folder exists, if not create it
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Function to process each image
def process_image(image_path, output_image_path, output_mask_path):
    # Load the image
    image = cv2.imread(image_path)

    # Check if the image was loaded correctly
    if image is None:
        raise FileNotFoundError(f"Image file not found at path: {image_path}")

    # Convert to grayscale
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply a Gaussian blur to smooth the image (reduce blur kernel size)
    blurred_image = cv2.GaussianBlur(gray_image, (25, 25), 0)

    # Thresholding to segment the epithelium
    _, thresholded_mask = cv2.threshold(blurred_image, 150, 255, cv2.THRESH_BINARY_INV)

    # Morphological operations to clean up the mask
    kernel_small = np.ones((20, 20), np.uint8)
    cleaned_mask = cv2.morphologyEx(thresholded_mask, cv2.MORPH_CLOSE, kernel_small)
    cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_OPEN, kernel_small)

    # Find contours to identify the epithelium region
    contours, _ = cv2.findContours(cleaned_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)

        # Create a blank mask to draw the epithelium contour
        epithelium_mask = np.zeros_like(cleaned_mask)
        cv2.drawContours(epithelium_mask, [largest_contour], -1, (255), thickness=cv2.FILLED)

        # Save the mask image
        cv2.imwrite(output_mask_path, epithelium_mask)

        # Calculate the width of the epithelium at multiple segments for each row
        def calculate_average_epithelium_width(mask):
            height = mask.shape[0]
            widths = []

            # Iterate through each row (y) in the image
            for y in range(height):
                row = mask[y, :]  # Get the row
                white_pixel_indices = np.where(row == 255)[0]  # Get the indices of white pixels (epithelium)

                # If there are white pixels in the row
                if len(white_pixel_indices) > 0:
                    # Separate the contiguous white segments
                    segments = np.split(white_pixel_indices, np.where(np.diff(white_pixel_indices) != 1)[0] + 1)

                    # Calculate the width of each segment and add to widths list
                    for segment in segments:
                        if len(segment) > 0:
                            width = segment[-1] - segment[0]
                            widths.append(width)

            # Calculate and return the average of all widths
            if len(widths) > 0:
                average_width = np.mean(widths)
            else:
                average_width = 0

            return int(average_width)

        # Get the average width of the epithelium
        average_epithelium_width = calculate_average_epithelium_width(epithelium_mask)
        print(f"Average epithelium width for {image_path}: {average_epithelium_width}")

        # Define the sliding window function
        def sliding_window(image, mask, step_size, window_size):
            # Slide a window across the image
            for y in range(0, image.shape[0] - window_size, step_size):
                for x in range(0, image.shape[1] - window_size, step_size):
                    yield (x, y, image[y:y + window_size, x:x + window_size], mask[y:y + window_size, x:x + window_size])

        # Limit the box size to 20% of the image size
        max_box_size = min(image.shape[0], image.shape[1]) * 0.2

        # Now applying the sliding window logic based on the mask
        window_size = min(average_epithelium_width, int(max_box_size))  # Square box size based on average epithelium width
        stride = window_size  # No overlap

        final_windows_image = image.copy()

        # Sliding window process
        for (x, y, window, window_mask) in sliding_window(image, epithelium_mask, stride, window_size):
            
            # Calculate the ratio of epithelium (white) area in the window
            total_area = window_mask.size
            epithelium_area = np.count_nonzero(window_mask)
            epithelium_ratio = epithelium_area / total_area
            
            # Draw a red box around the window if epithelium occupies more than 50%
            if epithelium_ratio > 0.50:
                # Expand the box
                x_start, y_start = x, y
                x_end, y_end = x + window_size, y + window_size

                # Ensure box does not exceed the max size
                if (x_end - x_start) <= max_box_size and (y_end - y_start) <= max_box_size:
                    cv2.rectangle(final_windows_image, (x_start, y_start), (x_end, y_end), (0, 0, 255), 8)

        # Save the final image with the windows drawn
        cv2.imwrite(output_image_path, final_windows_image)

        print(f"Processed and saved {output_image_path}, mask saved at {output_mask_path}")

    else:
        print(f"No epithelium contours were detected in {image_path}. Try adjusting the parameters.")

# Loop through all images in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith(".tif") or filename.endswith(".jpg") or filename.endswith(".png"):  # Adjust based on your file types
        input_image_path = os.path.join(input_folder, filename)
        output_image_path = os.path.join(output_folder, f"filtered_{filename}")
        output_mask_path = os.path.join(output_folder, f"mask_{filename}")

        # Process the image and save the output and mask
        process_image(input_image_path, output_image_path, output_mask_path)

print("Processing complete for all images.")
