import cv2
import numpy as np
from pathlib import Path
import time
import random

def get_epithelium_mask(image):
    """
    Get mask of epithelium tissue for dark background images
    For these specific images:
    - Black (0,0,0) = background
    - Purple/pink tissue = epithelium
    """
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Create background mask (black pixels)
    background_mask = gray < 10  # Threshold for nearly black pixels
    
    # Create tissue mask (non-black pixels)
    tissue_mask = ~background_mask
    
    # Optional: Clean up the mask using morphological operations
    kernel = np.ones((3,3), np.uint8)
    tissue_mask = cv2.morphologyEx(tissue_mask.astype(np.uint8), cv2.MORPH_CLOSE, kernel)
    tissue_mask = cv2.morphologyEx(tissue_mask, cv2.MORPH_OPEN, kernel)
    
    return tissue_mask.astype(bool)

def get_visible_region(image, left, top, right, bottom):
    """Get the visible portion of a region that may extend beyond image boundaries"""
    height, width = image.shape[:2]
    
    # Calculate visible region coordinates
    visible_left = max(0, left)
    visible_right = min(width, right)
    visible_top = max(0, top)
    visible_bottom = min(height, bottom)
    
    if visible_right <= visible_left or visible_bottom <= visible_top:
        return None, None, None, None
    
    return visible_left, visible_top, visible_right, visible_bottom

def calculate_coverage(epithelium_mask, existing_rectangles):
    """Calculate percentage of epithelium covered by samples"""
    if not existing_rectangles:
        return 0.0
    
    height, width = epithelium_mask.shape
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    
    for rect in existing_rectangles:
        left, top, right, bottom = rect
        # Get visible portion of the rectangle
        v_left, v_top, v_right, v_bottom = get_visible_region(
            np.zeros((height, width)), left, top, right, bottom
        )
        if v_left is not None:
            coverage_mask[v_top:v_bottom, v_left:v_right] = True
    
    total_epithelium = np.sum(epithelium_mask)
    if total_epithelium == 0:
        return 0.0
        
    covered_epithelium = np.sum(epithelium_mask & coverage_mask)
    return (covered_epithelium / total_epithelium) * 100

def calculate_overlap(rect1, rect2):
    """Calculate overlap percentage between two rectangles"""
    left1, top1, right1, bottom1 = rect1
    left2, top2, right2, bottom2 = rect2
    
    x_left = max(left1, left2)
    y_top = max(top1, top2)
    x_right = min(right1, right2)
    y_bottom = min(bottom1, bottom2)
    
    if x_right <= x_left or y_bottom <= y_top:
        return 0.0
    
    intersection = (x_right - x_left) * (y_bottom - y_top)
    area1 = (right1 - left1) * (bottom1 - top1)
    area2 = (right2 - left2) * (bottom2 - top2)
    
    return intersection / min(area1, area2)

def contains_tissue_and_background(image, left, top, right, bottom):
    """
    Check if visible portion of region contains both tissue and background.
    Requires black background pixels in at least 3 corners of the sample.
    """
    # Get visible portion of the region
    v_left, v_top, v_right, v_bottom = get_visible_region(image, left, top, right, bottom)
    if v_left is None:
        return False
    
    visible_region = image[v_top:v_bottom, v_left:v_right]
    if visible_region.size == 0:
        return False
    
    # Convert to grayscale
    gray = cv2.cvtColor(visible_region, cv2.COLOR_BGR2GRAY)
    
    # Define threshold for black pixels
    black_threshold = 10
    
    # Define corner regions (3x3 pixels for each corner to make it more robust)
    corner_size = 3
    corners = {
        'top_left': gray[0:corner_size, 0:corner_size],
        'top_right': gray[0:corner_size, -corner_size:],
        'bottom_left': gray[-corner_size:, 0:corner_size],
        'bottom_right': gray[-corner_size:, -corner_size:]
    }
    
    # Check each corner for black pixels
    corner_has_black = {
        corner: np.any(region < black_threshold)
        for corner, region in corners.items()
    }
    
    # Count corners with black pixels
    black_corners = sum(corner_has_black.values())
    
    # Check for tissue (non-black pixels) in the interior
    has_tissue = np.any(gray > black_threshold)
    
    # Require a minimum amount of both tissue and background
    min_percentage = 0.05  # Minimum 5% of each
    total_pixels = gray.size
    background_pixels = np.sum(gray < black_threshold)
    tissue_pixels = total_pixels - background_pixels
    
    background_percentage = background_pixels / total_pixels
    tissue_percentage = tissue_pixels / total_pixels
    
    # Return True only if:
    # 1. At least 3 corners have black pixels
    # 2. There is tissue present
    # 3. Minimum percentages of both tissue and background are met
    return (black_corners >= 3 and 
            has_tissue and 
            background_percentage >= min_percentage and 
            tissue_percentage >= min_percentage)

def get_epithelium_width_per_row(image):
    """
    Calculate epithelium width for each row using numpy operations
    """
    epithelium_mask = get_epithelium_mask(image)
    height = epithelium_mask.shape[0]
    width_dict = {}
    
    # Use numpy operations to find runs of True values
    for row in range(height):
        # Get row data
        row_data = epithelium_mask[row]
        if not np.any(row_data):
            continue
            
        # Find transitions
        transitions = np.where(np.diff(np.concatenate(([False], row_data, [False]))))[0]
        
        # Calculate widths of True segments
        widths = transitions[1::2] - transitions[::2]
        
        if len(widths) > 0:
            width_dict[row] = widths.tolist()
    
    return width_dict

def create_spatial_grid(image_shape, grid_size):
    """Create a spatial grid for faster neighbor lookups"""
    height, width = image_shape
    grid_rows = (height + grid_size - 1) // grid_size
    grid_cols = (width + grid_size - 1) // grid_size
    return [[[] for _ in range(grid_cols)] for _ in range(grid_rows)]

def add_to_grid(grid, rect, grid_size):
    """Add rectangle to spatial grid"""
    l, t, r, b = rect
    grid_left = max(0, l // grid_size)
    grid_right = min(len(grid[0]) - 1, r // grid_size)
    grid_top = max(0, t // grid_size)
    grid_bottom = min(len(grid) - 1, b // grid_size)
    
    for gr in range(grid_top, grid_bottom + 1):
        for gc in range(grid_left, grid_right + 1):
            grid[gr][gc].append(rect)

def get_nearby_samples(grid, rect, grid_size):
    """Get nearby samples from spatial grid"""
    l, t, r, b = rect
    grid_left = max(0, l // grid_size)
    grid_right = min(len(grid[0]) - 1, r // grid_size)
    grid_top = max(0, t // grid_size)
    grid_bottom = min(len(grid) - 1, b // grid_size)
    
    nearby = []
    seen = set()  # Avoid duplicates
    for gr in range(grid_top, grid_bottom + 1):
        for gc in range(grid_left, grid_right + 1):
            for sample in grid[gr][gc]:
                sample_tuple = tuple(sample)
                if sample_tuple not in seen:
                    nearby.append(sample)
                    seen.add(sample_tuple)
    return nearby

def save_visualization(image, output_dir, samples, scale, coverage):
    """Save visualization of samples at current scale"""
    viz_image = image.copy()
    height, width = viz_image.shape[:2]
    
    # Draw all samples
    for rect in samples:
        left, top, right, bottom = rect
        # Get visible portion of rectangle
        v_left, v_top, v_right, v_bottom = get_visible_region(viz_image, left, top, right, bottom)
        if v_left is not None:
            cv2.rectangle(viz_image, (v_left, v_top), (v_right, v_bottom), (0, 255, 0), 2)
    
    # Add coverage text
    cv2.putText(
        viz_image,
        f"Scale: {scale}x{scale}, Coverage: {coverage:.2f}%",
        (10, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 0, 255),
        2
    )
    
    output_path = output_dir / f"coverage_{scale}x{scale}.png"
    cv2.imwrite(str(output_path), viz_image)

def save_individual_samples(image, output_dir, samples, scale):
    """Save individual samples to separate files"""
    samples_dir = output_dir / f"samples_{scale}x{scale}"
    samples_dir.mkdir(exist_ok=True)
    
    # Create a metadata file for this scale
    with open(samples_dir / "metadata.txt", "w") as f:
        f.write(f"Scale: {scale}x{scale}\n")
        f.write(f"Total samples: {len(samples)}\n")
        f.write("\nSample coordinates (left, top, right, bottom):\n")
        
        for i, rect in enumerate(samples):
            # Save individual sample image
            left, top, right, bottom = rect
            v_left, v_top, v_right, v_bottom = get_visible_region(image, left, top, right, bottom)
            
            if v_left is not None:
                sample_img = image[v_top:v_bottom, v_left:v_right].copy()
                # Add border to visualize the sample
                sample_img = cv2.copyMakeBorder(
                    sample_img, 2, 2, 2, 2, cv2.BORDER_CONSTANT, value=(0, 255, 0)
                )
                cv2.imwrite(str(samples_dir / f"sample_{i+1:04d}.png"), sample_img)
                
                # Write coordinates to metadata
                f.write(f"Sample {i+1:04d}: {rect}\n")
                f.write(f"Visible region: ({v_left}, {v_top}, {v_right}, {v_bottom})\n")

def save_coverage_statistics(output_dir, scale_results, total_coverage, image_name):
    """Enhanced coverage statistics with total coverage information"""
    with open(output_dir / "coverage_statistics.txt", "w") as f:
        f.write(f"Coverage Analysis for {image_name}\n")
        f.write("=" * 50 + "\n\n")
        
        f.write("Overall Coverage Statistics:\n")
        f.write(f"Total Coverage: {total_coverage:.2f}%\n")
        f.write("-" * 50 + "\n\n")
        
        for scale, (samples, coverage) in scale_results.items():
            f.write(f"Scale: {scale}x{scale}\n")
            f.write(f"Samples placed: {len(samples)}\n")
            f.write(f"Final coverage: {coverage[-1] if coverage else 0.0:.2f}%\n")
            f.write("\nCoverage progression:\n")
            for i, cov in enumerate(coverage, 1):
                if i % 10 == 0 or i == len(coverage):  # Log every 10th sample and final
                    f.write(f"  Sample {i}: {cov:.2f}%\n")
            f.write("-" * 50 + "\n\n")

def process_tissue_at_scale(image, scale_size, existing_samples, width_dict):
    """Process tissue exhaustively at each scale until no valid areas remain"""
    height, width = image.shape[:2]
    epithelium_mask = get_epithelium_mask(image)
    samples_at_scale = []
    coverage_history = []
    
    # Set overlap threshold based on scale
    if scale_size <= 128:
        overlap_threshold = 0.20
    elif scale_size <= 256:
        overlap_threshold = 0.30
    else:  # 512
        overlap_threshold = 0.40
    
    print(f"\nProcessing scale: {scale_size}x{scale_size}")
    print(f"Overlap threshold: {overlap_threshold*100}%")
    
    # Create spatial grid for fast neighbor lookups
    grid_size = scale_size
    spatial_grid = create_spatial_grid((height, width), grid_size)
    
    # Add existing samples to grid
    for rect in existing_samples:
        add_to_grid(spatial_grid, rect, grid_size)
    
    # Pre-calculate valid points on epithelium
    valid_points = np.where(epithelium_mask)
    valid_points = list(zip(valid_points[1], valid_points[0]))  # x, y coordinates
    random.shuffle(valid_points)  # Randomize points
    
    if not valid_points:
        return [], []
    
    # Initialize efficient tracking of coverage
    coverage_mask = np.zeros_like(epithelium_mask, dtype=bool)
    for rect in existing_samples:
        l, t, r, b = rect
        vl, vt, vr, vb = get_visible_region(coverage_mask, l, t, r, b)
        if vl is not None:
            coverage_mask[vt:vb, vl:vr] = True
    
    half_size = scale_size // 2
    consecutive_failures = 0
    total_attempts = 0
    
    print("Starting exhaustive sampling...")
    
    while valid_points and consecutive_failures < 1000:
        total_attempts += 1
        
        if total_attempts % 1000 == 0:
            print(f"Attempts: {total_attempts}, Valid points remaining: {len(valid_points)}")
            print(f"Current samples: {len(samples_at_scale)}")
        
        # Get next point
        center_x, center_y = valid_points.pop()
        
        rect = (
            center_x - half_size,
            center_y - half_size,
            center_x + half_size,
            center_y + half_size
        )
        
        # Quick boundary check
        if not (0 <= center_y < height and 0 <= center_x < width):
            consecutive_failures += 1
            continue
        
        # Check if contains tissue and background
        if not contains_tissue_and_background(image, *rect):
            consecutive_failures += 1
            continue
        
        # Check overlap only with nearby samples
        valid_sample = True
        nearby_samples = get_nearby_samples(spatial_grid, rect, grid_size)
        
        for other_rect in nearby_samples:
            if calculate_overlap(rect, other_rect) > overlap_threshold:
                valid_sample = False
                break
        
        if not valid_sample:
            consecutive_failures += 1
            continue
        
        # Valid sample found
        consecutive_failures = 0
        samples_at_scale.append(rect)
        add_to_grid(spatial_grid, rect, grid_size)
        
        # Update coverage mask
        l, t, r, b = rect
        vl, vt, vr, vb = get_visible_region(coverage_mask, l, t, r, b)
        if vl is not None:
            coverage_mask[vt:vb, vl:vr] = True
        
        # Check coverage periodically
        if len(samples_at_scale) % 10 == 0:
            current_coverage = np.sum(coverage_mask & epithelium_mask) / np.sum(epithelium_mask) * 100
            coverage_history.append(current_coverage)
            print(f"Current coverage: {current_coverage:.2f}%")
            print(f"Samples placed: {len(samples_at_scale)}")
    
    # Calculate final coverage
    final_coverage = np.sum(coverage_mask & epithelium_mask) / np.sum(epithelium_mask) * 100
    coverage_history.append(final_coverage)
    
    print(f"\nScale {scale_size}x{scale_size} completed:")
    print(f"Total samples placed: {len(samples_at_scale)}")
    print(f"Final coverage at this scale: {final_coverage:.2f}%")
    print(f"Total attempts made: {total_attempts}")
    
    return samples_at_scale, coverage_history

def process_tissue(image_path, debug_output_dir):
    """Process tissue image with exhaustive multi-scale sampling"""
    image = cv2.imread(str(image_path))
    if image is None:
        print(f"Failed to read image: {image_path}")
        return None, None, None
    
    # Calculate epithelium widths for all rows
    width_dict = get_epithelium_width_per_row(image)
    
    # Define scales in order from smallest to largest
    scales = [128, 256, 512]
    
    all_samples = []
    scale_results = {}
    epithelium_mask = get_epithelium_mask(image)
    
    # Create output directory
    debug_output_dir = Path(debug_output_dir)
    debug_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save the epithelium mask for verification
    mask_viz = np.zeros_like(image)
    mask_viz[epithelium_mask] = [0, 255, 0]  # Green for tissue
    cv2.imwrite(str(debug_output_dir / "epithelium_mask.png"), mask_viz)
    
    for scale in scales:
        print(f"\nStarting scale {scale}x{scale}")
        print("=" * 50)
        
        # Process at current scale
        samples_at_scale, coverage_history = process_tissue_at_scale(
            image,
            scale,
            all_samples,
            width_dict
        )
        
        all_samples.extend(samples_at_scale)
        scale_results[scale] = (samples_at_scale, coverage_history)
        
        # Save individual samples
        save_individual_samples(image, debug_output_dir, samples_at_scale, scale)
        
        # Save visualization for this scale
        save_visualization(
            image,
            debug_output_dir,
            all_samples,
            scale,
            coverage_history[-1] if coverage_history else 0.0
        )
        
        # Calculate and display intermediate total coverage
        current_total_coverage = calculate_coverage(epithelium_mask, all_samples)
        print(f"Total coverage after {scale}x{scale}: {current_total_coverage:.2f}%")
    
    # Calculate final total coverage
    total_coverage = calculate_coverage(epithelium_mask, all_samples)
    
    # Save final statistics
    save_coverage_statistics(
        debug_output_dir, 
        scale_results, 
        total_coverage,
        image_path.name
    )
    
    return all_samples, scale_results, total_coverage

def main():
    input_folder = Path("Krish_files")
    output_folder = Path("new_output")
    output_folder.mkdir(exist_ok=True)
    
    # Track overall statistics across all images
    overall_stats = []
    
    for image_path in input_folder.iterdir():
        if image_path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.tif']:
            print(f"\nProcessing: {image_path}")
            
            image_output_dir = output_folder / image_path.stem
            image_output_dir.mkdir(parents=True, exist_ok=True)
            
            try:
                samples, scale_results, total_coverage = process_tissue(image_path, image_output_dir)
                if samples is None:
                    continue
                    
                # Save to overall statistics
                overall_stats.append({
                    'image': image_path.name,
                    'total_coverage': total_coverage,
                    'samples_by_scale': {
                        scale: len(samples_at_scale) 
                        for scale, (samples_at_scale, _) in scale_results.items()
                    }
                })
                
                # Print summary
                print("\nProcessing Summary:")
                print(f"Total Coverage: {total_coverage:.2f}%")
                for scale, (samples_at_scale, coverage_history) in scale_results.items():
                    print(f"\nScale {scale}x{scale}:")
                    print(f"Samples placed: {len(samples_at_scale)}")
                    print(f"Final coverage: {coverage_history[-1] if coverage_history else 0.0:.2f}%")
                       
            except Exception as e:
                print(f"Error processing {image_path}: {str(e)}")
                import traceback
                traceback.print_exc()
    
    # Calculate average coverage and other aggregate statistics
    if overall_stats:
        total_images = len(overall_stats)
        average_coverage = sum(stats['total_coverage'] for stats in overall_stats) / total_images
        max_coverage = max(stats['total_coverage'] for stats in overall_stats)
        min_coverage = min(stats['total_coverage'] for stats in overall_stats)
        
        # Calculate average samples per scale
        scales = set()
        for stats in overall_stats:
            scales.update(stats['samples_by_scale'].keys())
        
        avg_samples_by_scale = {}
        for scale in scales:
            samples_at_scale = [
                stats['samples_by_scale'].get(scale, 0) 
                for stats in overall_stats
            ]
            avg_samples_by_scale[scale] = sum(samples_at_scale) / len(samples_at_scale)
    
    # Save overall statistics with new aggregate metrics
    with open(output_folder / "overall_statistics.txt", "w") as f:
        f.write("Overall Processing Statistics\n")
        f.write("=" * 50 + "\n\n")
        
        # Write aggregate statistics first
        if overall_stats:
            f.write("Aggregate Statistics\n")
            f.write("-" * 30 + "\n")
            f.write(f"Total images processed: {total_images}\n")
            f.write(f"Average coverage across all tissues: {average_coverage:.2f}%\n")
            f.write(f"Maximum coverage: {max_coverage:.2f}%\n")
            f.write(f"Minimum coverage: {min_coverage:.2f}%\n")
            f.write("\nAverage samples per scale:\n")
            for scale in sorted(scales):
                f.write(f"  {scale}x{scale}: {avg_samples_by_scale[scale]:.1f} samples\n")
            f.write("\n" + "=" * 50 + "\n\n")
        
        # Write individual image statistics
        f.write("Individual Image Statistics\n")
        f.write("-" * 30 + "\n\n")
        for stats in overall_stats:
            f.write(f"Image: {stats['image']}\n")
            f.write(f"Total Coverage: {stats['total_coverage']:.2f}%\n")
            f.write("Samples by scale:\n")
            for scale, count in stats['samples_by_scale'].items():
                f.write(f"  {scale}x{scale}: {count} samples\n")
            f.write("-" * 50 + "\n\n")

if __name__ == "__main__":
    main()